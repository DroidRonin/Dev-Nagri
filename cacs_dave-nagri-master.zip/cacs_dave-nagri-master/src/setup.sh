#!/bin/bash
pip install tokenizers
pip install transformers
pip install torch
pip install sklearn
pip install pandas
pip install numpy
pip install matplotlib
pip install seaborn 
pip install pandas 
  