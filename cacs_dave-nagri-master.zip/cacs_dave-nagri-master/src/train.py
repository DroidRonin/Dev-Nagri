#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 19:03:35 2020

@author: DroidRonin
"""

import tokenizers
import transformers
import torch
from torch import nn
from sklearn import metrics, model_selection

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
#%matplotlib inline
from tqdm.notebook import tqdm
import warnings
warnings.filterwarnings('ignore')
import logging
logging.basicConfig(level=logging.ERROR)

from pathlib import Path
import os

#user = !whoami
#user

p = Path.cwd()  # src directory
os.chdir(f"{p}/../Data")  # cwd = data directory

# map tokens to gold LID label
class Config:
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    MAX_LEN = 140
    TRAIN_BATCH_SIZE = 8
    VALID_BATCH_SIZE = 4
    EPOCHS = 5
    LR=0.2*3e-5
    BERT_PATH=f"bert-uncased-multilingual-tensorflow"  # name of the additional folder uploaded on Google Drive
    TOKENIZER = transformers.BertTokenizer.from_pretrained(BERT_PATH, do_lower_case=True)
    CLASS_MAPPING = {'pad':0, 'en':1, 'hi':2, 'ne':3, 'univ':4, 'acro':5}
    #CLASS_MAPPING converts every LID label to an index number
    MAPPING2CLASS = {i:j for j,i in CLASS_MAPPING.items()}

# Data preprocessing for training data
# isolates romanised words and their gold LID labels
f = open('tweets_train.conll', 'r', encoding='utf-8')

tokens = []
LIDs = []

sentence_tokens = []
sentence_lids = []

for line in f:  # token level
    if line != '\n':
        columns = line.split('\t')  # isolate columns

    if line == '\n':
        # add sentences to tokens/LIDs
        tokens.append(sentence_tokens)
        LIDs.append(sentence_lids)

        # reset lists for next sentence
        sentence_tokens = []
        sentence_lids = []

    # add romanised words to sent_tokens, LIDs to sent_lids
    else:
        sentence_tokens.append(columns[1])
        sentence_lids.append(columns[-2])


# maps romanised words to gold LID labels
LID_mapped = []

for i in LIDs:
    LID_mapped.append([Config.CLASS_MAPPING.get(i, 0) for i in i])

# splits data into train/validation
train_tokens, valid_tokens, train_labels, valid_labels=model_selection.train_test_split(tokens, LID_mapped, test_size=0.2)

# creating data for BERT training
class BERTDatasetTraining:
    def __init__(self, query, targets, tokenizer, max_length):
        '''
        Dataset function used for training the notebooks.
        This is used for training pipelines.
        Args:
            query: pd.Series: The columnar series of the dataset that you want your model to train upon.
            targets: pd.Series: The columnar series of the targets associated with your inputs.
            tokenizer: Here we are experimenting with only two tokenizers. 1. WordSplitTokenization, 2. BytePairTokenization
            max_lenght: int: What is the maximum width of a sentence that we want to work on.
        '''
        self.comment_text = query
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.targets = targets

    def __len__(self):
        '''
        This should be particularly based on the number of datapoints in the training set.
        '''
        return len(self.comment_text)

    def __getitem__(self, item):
        comment_text = " ".join(self.comment_text[item])

        inputs = self.tokenizer.encode_plus(
                comment_text,
                None,
                add_special_tokens=True,
                max_length=self.max_length,
        )

        input_len = len(inputs["input_ids"])
        ids = inputs["input_ids"]
        token_type_ids = inputs["token_type_ids"]
        mask = inputs["attention_mask"]

        padding_length = self.max_length - len(ids)

        ids = ids + ([0] * padding_length)
        mask = mask + ([0] * padding_length)
        token_type_ids = token_type_ids + ([0] * padding_length)
        targets = self.targets[item] + ([0] * (Config.MAX_LEN - len(self.targets[item])))

        return {
                'ids': torch.tensor(ids, dtype=torch.long),
                'mask': torch.tensor(mask, dtype=torch.long),
                'token_type_ids': torch.tensor(token_type_ids, dtype=torch.long),
                'tokens': self.comment_text[item],
                'targets': torch.tensor(targets, dtype=torch.float)
        }

dataset = BERTDatasetTraining(train_tokens, train_labels, Config.TOKENIZER, Config.MAX_LEN)
train = next(iter(torch.utils.data.DataLoader(dataset, batch_size=len(train_tokens))))
# same variable name? maybe dataset2?
dataset = BERTDatasetTraining(valid_tokens, valid_labels, Config.TOKENIZER, Config.MAX_LEN)
valid = next(iter(torch.utils.data.DataLoader(dataset, batch_size=len(valid_tokens))))

# 
' '.join(Config.TOKENIZER.convert_ids_to_tokens(dataset[0]['ids']))

# initiating and training the model
from transformers import BertConfig, TFBertModel
import tensorflow as tf

ids = tf.keras.layers.Input((Config.MAX_LEN), dtype=tf.int32)
att = tf.keras.layers.Input((Config.MAX_LEN), dtype=tf.int32)
tok = tf.keras.layers.Input((Config.MAX_LEN), dtype=tf.int32)

config = BertConfig.from_pretrained('bert-uncased-multilingual-tensorflow/config.json')
bert_model = TFBertModel.from_pretrained('bert-uncased-multilingual-tensorflow/tf_model.h5',config=config)
x = bert_model(ids)
x1 = tf.keras.layers.Dropout(0.1)(x[0])
x1 = tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(len(Config.CLASS_MAPPING), activation='softmax'), name='TimeDistLabel')(x1)
print(x1.shape)

model = tf.keras.models.Model(inputs=ids, outputs=x1)
optimizer = tf.keras.optimizers.Adam(learning_rate=3e-5)
model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy', tf.keras.metrics.AUC()])
model.summary()

train_labels_oh = tf.keras.utils.to_categorical(train['targets'].numpy(), len(Config.CLASS_MAPPING))
valid_labels_oh = tf.keras.utils.to_categorical(valid['targets'].numpy(), len(Config.CLASS_MAPPING))

model.fit(x=train['ids'].numpy(), y=train_labels_oh, 
          validation_data=(valid['ids'].numpy(), valid_labels_oh),
         batch_size=Config.TRAIN_BATCH_SIZE,
         epochs=2,  # change back to 5
         )

p = Path.cwd()  # data directory
os.chdir(f"{p}/../outputs")  # outputs directory

model.save_weights("train_model.h5", overwrite=True)

p = Path.cwd()  # outputs directory
os.chdir(f"{p}/../src")  # src directory
