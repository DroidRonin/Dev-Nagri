#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 15:10:58 2020

@author: Kate
"""


import nltk
from nltk.tokenize.treebank import TreebankWordDetokenizer as tbwd
import csv
from itertools import zip_longest
from pathlib import Path
import os

# getting the trained model to predict labels
p = Path.cwd()  # src directory
os.chdir(f"{p}/../outputs")  # outputs directory

model.load_weights("train_model.h5")

p = Path.cwd()  # outputs directory
os.chdir(f"{p}/../src")  # src directory

# predict labels
def predicted(file, name):
    f = open(file, 'r', encoding='utf-8')

    # all tokens/LIDs for each sentence
    tokens = []  # [[s1 tokens], [s2 tokens]]
    LIDs = []  # [[s1 LIDs], [s2 LIDs]]

    sentence_tokens = []
    sentence_lids = []

    for line in f:  # token level
        # isolate columns
        if line != '\n':
            columns = line.split('\t')

        if line == '\n':
            # add sentences to tokens/LIDs
            tokens.append(sentence_tokens)
            LIDs.append(sentence_lids)

            # reset lists for next sentence
            sentence_tokens = []
            sentence_lids = []

        # add romanised words to sent_tokens, LIDs to sent_lids
        else:
            sentence_tokens.append(columns[1])
            sentence_lids.append(columns[-2])

    # data preprocessing: detokenize each sentence to feed into model
    sentences = []
    for sentence in tokens:
        sentences.append(tbwd().detokenize(sentence))

    # run each sentence in model and predict LIDs
    # saves LID indexes e.g. [1, 3, 2, 0, 4]
    predicted_sentences = []
    for sentence in sentences:
        tokens1 = Config.TOKENIZER.encode_plus(sentence,
                                              None,
                                              add_special_tokens=True,
                                              max_length=Config.MAX_LEN,
                                              )
        padding_length = Config.MAX_LEN - len(tokens1['input_ids'])
        ids = tokens1['input_ids'] + ([0] * padding_length)
        inp = np.array([ids])
        res = model.predict(inp)
        sent_length = len(sentence)
        padded_sentence = [Config.MAPPING2CLASS[i] for i in res.argmax(-1)[0]]
        # pred_sentence = padded_sentence[0:sent_length]
        # predicted_sentences.append(padded_sentence[0:sent_length])
        non_pad = list(filter(lambda a: a != 'pad', pred_sentence))
        predicted_sentences.append(non_pad)
        
    # create CSV file to save the tokens, gold LIDs, and predicted LIDs for
    # each sentence
    dev = []
    dev.append(tokens)
    dev.append(LIDs)
    dev.append(predicted_sentences)

    export_data = zip_longest(*dev, fillvalue = '')

    p = Path.cwd()  # src directory
    os.chdir(f"{p}/../outputs")  # outputs directory

    with open(name + '.csv', 'w') as new_file:
        wr = csv.writer(new_file)
        wr.writerow(['tokens', 'gold', 'predicted'])
        wr.writerows(export_data)
    new_file.close()
    
    p = Path.cwd()  # outputs directory
    os.chdir(f"{p}/../src")  # src directory


predicted('tweets_dev.conll', 'dev')
predicted('tweets_test.conll', 'test')
