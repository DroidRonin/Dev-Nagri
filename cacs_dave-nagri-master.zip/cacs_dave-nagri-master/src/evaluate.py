#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 21:06:12 2020

@author: Kate
"""


import csv
from pathlib import Path
import os

def get_accuracy(file):
    # access the saved data from the file
    sentences = []  # [([gold LIDs], [pred LIDs]), ([gold LIDs], [pred LIDs])]

    with open(file) as new_file:
        reader = csv.reader(new_file, delimiter=',')
        for row in reader:
            # need to convert saved string back into a list for gold/predicted
            gold1 = row[1].strip("][").split(', ')
            gold = []
            for token in gold1:
                gold.append(token.strip("'"))
    
            pred1 = row[2].strip("]['").split(', ')
            pred = []
            for token in pred1:
                pred.append(token.strip("'"))
            sentences.append((gold, pred))

    # get length of vocabulary to calculate accuracy
    all_words = []

    for sentence in sentences[1:]:
        for token in sentence[0]:
            all_words.append(token)

    vocabulary = len(all_words)

    return(sentences, vocabulary)


def find_tps(lid, gold_s, pred_s):  # 'hi', [gold], [pred]
    tp_count = 0
    for i in range(len(gold_s)):
        if gold_s[i] == lid and pred_s[i] == lid:
            tp_count += 1
    return tp_count


def main():
    p = Path.cwd()  # src directory
    os.chdir(f"{p}/../outputs")  # outputs directory

    # get accuracy for dev data
    dev = get_accuracy("dev.csv")  # returns (sentences, vocabulary)
    dev_tps = 0
    for sentence in dev[0][1:]:
        dev_tps += find_tps('hi', sentence[0], sentence[1])
        dev_tps += find_tps('en', sentence[0], sentence[1])
        dev_tps += find_tps('ne', sentence[0], sentence[1])
        dev_tps += find_tps('acro', sentence[0], sentence[1])
        dev_tps += find_tps('univ', sentence[0], sentence[1])

    dev_accuracy = dev_tps/dev[1]

    # get accuracy for test data
    test = get_accuracy("test.csv")
    test_tps = 0
    for sentence in test[0][1:]:
        test_tps += find_tps('hi', sentence[0], sentence[1])
        test_tps += find_tps('en', sentence[0], sentence[1])
        test_tps += find_tps('ne', sentence[0], sentence[1])
        test_tps += find_tps('acro', sentence[0], sentence[1])
        test_tps += find_tps('univ', sentence[0], sentence[1])

    test_accuracy = test_tps/test[1]

    # saves file
    with open("results.tsv", "wt") as new_file:
        tsv_writer = csv.writer(new_file, delimiter='\t')
        tsv_writer.writerow(['dev accuracy: ', 'test accuracy'])
        tsv_writer.writerow([dev_accuracy, test_accuracy])
    new_file.close()

    return

main()
